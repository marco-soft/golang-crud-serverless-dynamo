<!--
title: TODO
description: This example demonstrates how to setup a simple HTTP endpoint in Go.
layout: Doc
framework: v1
platform: AWS
language: Go
priority: 10
authorLink: 'https://github.com/sebito91'
authorName: 'Sebastian Borza'
authorAvatar: 'https://avatars0.githubusercontent.com/u/3159454?v=4&s=140'
-->
